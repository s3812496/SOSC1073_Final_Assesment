public class VIPCart extends ShoppingCart{



}
